Please copy these two files to your working directory and modify it 
with model building to fit your need. Rename it if necessary. These 
two files are for single subject only. Then type 'source("fitmodel.R")'
(no single quote with the correct file name) to run it.